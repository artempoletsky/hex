var Map = ViewModel.extend({
    el: '.map',
    arr: [],
    game: undefined,
    constructor: function (game) {
        this.game = game;
        this._super();

    },
    attributes: {
        size_x: 5,
        size_y: 5
    },
    events: {
        'mouseenter .hex': 'onHexOver',
        'mouseleave .hex': 'onMouseLeave',
        'click .hex': 'onHexClick'
    },
    currentArmy: undefined,
    onMouseLeave: function(){
        this.$('.highlighted').removeClass('highlighted');
    },
    onHexOver: function (e) {
        var $el = $(e.currentTarget);
        if (this.currentArmy) {
            this.highlightHexagons(this.line(this.currentArmy.hex, this.at($el.attr('x'), $el.attr('y'))));
        }
    },
    onHexClick: function (e) {
        var $el = $(e.currentTarget);
        this.currentArmy.move(this.at($el.attr('x'), $el.attr('y')));
    },
    generateHexagons: function () {
        for (var j = 0; j < this.prop('size_y'); j++) {
            var row = [];
            this.arr.push(row);
            for (var i = 0; i < this.prop('size_x'); i++) {
                var hex = new Hex({
                    game: this.game,
                    map: this,
                    x: i,
                    y: j
                });

                row.push(hex);
            }
        }
    },
    drawHexagons: function () {
        var $map = this.$('.hexagons');
        $map.empty();
        for (var j = 0; j < this.prop('size_y'); j++) {
            for (var i = 0; i < this.prop('size_x'); i++) {
                var hex = this.arr[j][i];
                hex.$el.css({
                    left: hex.prop('left'),
                    top: hex.prop('top')
                })
                $map.append(hex.$el);
            }
        }
    },


    addBuilding: function (building, hex) {
        this.$('.buildings').append(building.$el);
        this.game.copyPosition(building.$el, hex);
    },

    addArmy: function (army, hex) {
        this.$('.units').append(army.$el);
        army.setPosition(hex);
    },
    highlightHexagons: function (hexagons) {
        this.$('.highlighted').removeClass('highlighted');
        _.each(hexagons, function (hex) {
            hex.$el.addClass('highlighted');
        });
    },
    line: function (from, to) {
        var result = [from];
        var tx = to.prop('pos_x'),
            ty = to.prop('pos_y');

        var current = from;
        while (current != to) {
            current = _.min(this.siblings(current), function (hex) {
                return Math.abs(hex.prop('pos_x') - tx) + Math.abs(hex.prop('pos_y') - ty) / 2;
            });
            result.push(current);
        }
        return result;
    },
    siblings: function (hex) {
        var x = hex.prop('pos_x'),
            y = hex.prop('pos_y');
        return (x % 2) ?
            _.compact([
                this.at(x, y - 1),
                this.at(x, y + 1),
                this.at(x - 1, y),
                this.at(x + 1, y),
                this.at(x - 1, y + 1),
                this.at(x + 1, y + 1)
            ]) : _.compact([
            this.at(x, y - 1),
            this.at(x, y + 1),
            this.at(x - 1, y),
            this.at(x + 1, y),
            this.at(x - 1, y - 1),
            this.at(x + 1, y - 1)
        ]);
    },
    at: function (x, y) {
        if (!this.arr[y]) {
            return;
        }
        return this.arr[y][x];
    }
});