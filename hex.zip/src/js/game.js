$(function () {


    ViewModel.create({
        el: 'body',
        events: {
            'click .toggle_frames': 'toggleFrames',
            'click .end_turn': 'turn'
        },
        shortcuts: {
            $map: '.map'
        },
        toggleFrames: function () {
            this.$map.toggleClass('hide_frames');
        },
        selectArmy: function(army){
            this.unitMenu.setUnit(army);
            this.map.currentArmy = army;
        },
        deselectArmy: function(){
            this.map.currentArmy=undefined;
            this.unitMenu.hide();
        },
        alert: function (message) {
            alert(message);
        },
        confirm: function (message, callback) {
            callback(confirm(message));
        },
        initialize: function () {
            ViewModel.findBinds('.templates');

            this.unitMenu = new UnitMenu(this);
            var map = new Map(this);

            this.map = map;
            map.prop('size_x', 20);
            map.prop('size_y', 10);

            map.generateHexagons();
            map.drawHexagons();


            var player = this.player = new Player(this);

            player.addArmy([new Unit()], map.at(7,7));

        },
        copyPosition: function ($el, hex) {
            $el.css({
                left: hex.prop('left') + 'px',
                top: hex.prop('top') + 'px'
            });
        },
        turn: function () {

        }
    });


});
