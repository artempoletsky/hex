var Settlement = Building.extend({
    buildings: undefined,
    storage: undefined,

    unitsContainer: undefined,
    initialize: function () {
        this.buildings = new Collection();
        this.storage = new Resources();
        this.unitsContainer=new UnitsContainer(this.game, this.player, []);
    },
    removeBuilding: function (building) {
        this.buildings.cutByCid(building.cid);
    },
    build: function (hex, building_id) {
        var b = new BuildingsList[building_id];
        b.settlement = this;
        b.hex = hex;
        b.build();
        this.buildings.add(b);
    },
    turn: function () {
        var models = this.buildings.models.slice(0);
        _.each(models, function (building) {
            building.turn();
        });
    }
});